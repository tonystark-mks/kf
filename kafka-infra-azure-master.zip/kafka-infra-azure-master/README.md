# kafka-cluster-infra-azure
End-to-end kafka cluster deployment pipeline on azure
